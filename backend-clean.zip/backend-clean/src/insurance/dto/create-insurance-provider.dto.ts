export class CreateInsuranceProviderDto {
  name!: string;
  website?: string;
  contactEmail?: string;
}
